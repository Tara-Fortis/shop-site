<?php
// menu in wp
function scenarioone_register_menu()
{
  register_nav_menus(
    array(
      'header-menu'       => __('Header Menu'),
      'footer-menu'       => __('Footer Menu')
    )
  );
}
add_action('after_setup_theme', 'scenarioone_register_menu');
//featured images
add_theme_support('post-thumbnails');
// add background image
add_theme_support('custom-background');
function customtheme_add_woocommerce_support()
{
  add_theme_support('woocommerce');
}
add_action('after_setup_theme', 'customtheme_add_woocommerce_support');
function enqueue_wc_cart_fragments()
{
  wp_enqueue_script('wc-cart-fragments');
}
add_action('wp_enqueue_scripts', 'enqueue_wc_cart_fragments');
add_theme_support('wc-product-gallery-zoom');
add_theme_support( 'wc-product-gallery-lightbox' );
add_theme_support( 'wc-product-gallery-slider' );
function my_theme_enqueue_styles()
{
  wp_enqueue_style('woocommerce-style', get_template_directory_uri() . '/woocommerce.css');
}
add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles');
//reorder the apperance of the product page
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_meta', 40 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 30 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 5 );
remove_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 10 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 10 );
remove_action( 'woocommerce_product_additional_information', 'wc_display_product_attributes', 10 );
remove_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );

add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_title', 0 );
add_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_product_data_tabs', 15 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_price', 15 );
add_action( 'woocommerce_single_product_summary', 'woocommerce_template_single_add_to_cart', 15 );
add_action( 'woocommerce_after_single_product_summary', 'woocommerce_output_related_products', 20 );
remove_action( 'woocommerce_product_additional_information', 'wc_display_product_attributes', 20 );