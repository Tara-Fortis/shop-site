<?php
get_header();
?>
<section>
    <h1><?php the_title(); ?></h1>
    <?php woocommerce_content(); ?>
</section>
<?php
get_footer();
?>