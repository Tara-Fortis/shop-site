<?php
/**
 * Template Name: Scenario One
 * Template Post Type: post
 */
    get_header();
?>
<section>
    <?php 
        while ( have_posts() ) : the_post();
        get_template_part( 'content', get_post_format());
        if ( comments_open() || get_comments_number()) :
            comments_template();
        endif;
    endwhile;
    ?>
</section>
<?php
    get_footer();
?>