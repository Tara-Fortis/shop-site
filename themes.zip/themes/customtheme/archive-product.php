<?php
get_header();
$shopFeaturedImg = wp_get_attachment_image_src( get_post_thumbnail_id( wc_get_page_id( 'shop')), 'thumbnail' );
?>
<section>
        <h1>Cozy Bookstore Shop</h1>
</section>
<section>
    <?php
        do_action( 'woocommerce_before_shop_loop' );
            echo do_shortcode ( '[products limit="4" columns="4" orderby="price"]' );
        do_action( 'woocommerce_after_shop_loop' );
    ?>
</section>
<?php
get_footer();