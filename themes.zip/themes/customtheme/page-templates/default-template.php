<?php

/**
 * Template Name: Default
 * Template Post Type: page 
 */
get_header();
?>
<section>
    <h1><?php echo wp_kses_post(the_field('title_text')) ?></h1>
    <p><?php echo get_the_content('body_text'); ?> </p>
</section>
<?php
get_footer();
?>