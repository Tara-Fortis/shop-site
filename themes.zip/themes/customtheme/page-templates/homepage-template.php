<?php

/**
 * Template Name: Scenario One
 * Template Post Type: page 
 */
get_header();
?>
<section>
    <h1><?php echo wp_kses_post(the_field('masthead_title')) ?></h1>
    <p><?php echo get_the_content('body_text'); ?> </p>
</section>
<?php
get_footer();
?>